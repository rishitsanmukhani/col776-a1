g++ -std=c++11 q1a.cpp -o q1a.out
./q1a.out $1 $2 > bn.txt