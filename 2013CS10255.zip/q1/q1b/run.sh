g++ -std=c++11 q1b.cpp -o q1b.out
./q1b.out $1 $2 > out.txt